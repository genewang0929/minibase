package lshfindex;

import global.*;
import java.util.*;
import diskmgr.*;
import bufmgr.*;
import heap.*;
import btree.*;
import iterator.*;
import java.io.*;

/**
 * LSHFPrefixTree implements a prefix tree for the LSH-Forest.
 * It uses the btree package template: internal (index) pages hold <key, PageID> pairs
 * and leaf pages hold <key, RID> pairs. For simplicity, this implementation starts with
 * a single leaf page (i.e. no internal nodes) and does not implement full node splitting.
 *
 * The tree supports insertion, scanning all entries, range search, and nearest neighbor search.
 */
public class LSHFPrefixTree {

  private static boolean DEBUG = true;
  
  // File name (base) for this prefix tree (used for header and pages)
  private String fileName;
  
  // Maximum key size (in our case, the number of hash values concatenated; equals h)
  private int keySize;
  
  // The key type: our hash keys are strings.
  private int keyType = AttrType.attrString;
  
  // The header page for the tree
  private LSHFPrefixTreeHeaderPage headerPage;

  private PageId headerPageId;
  
  // The PageId of the root node.
  // For simplicity, if the tree is new, the root is a leaf page.
  private PageId rootId;
  
  // A constant for maximum records per leaf page. (In a full implementation, this
  // is determined by the page size.)
  private static final int MAX_RECORDS_PER_LEAF = 100;

  private final static int MAGIC0=1989;
  
  /**
   * Constructs a new LSHFPrefixTree.
   * This constructor creates a new tree with an empty header and no root.
   * @param fileName the base file name to be used for storing tree pages.
   * @param keySize the maximum key length (number of hash values to be concatenated).
   * @throws Exception if tree creation fails.
   */
  public LSHFPrefixTree(String fileName, int keySize) throws Exception {
    if (DEBUG) {
      System.out.println("[LSHFPrefixTree] Creating LSHFPrefixTree " + fileName);
    }
    this.fileName = fileName;
    this.keySize = keySize;
    
    // Create a new header page.
    // In a full system, we would check if the file exists and open it; here we always create a new tree.
    if (DEBUG) {
      System.out.println("[LSHFPrefixTree] Creating header page");
    }

    // get_file_entry from DB.java
    headerPageId = get_file_entry(fileName);
    if (headerPageId == null) {
      headerPage = new LSHFPrefixTreeHeaderPage();
      headerPageId = headerPage.getPageId();
      add_file_entry(fileName, headerPageId);
      headerPage.set_magic0(MAGIC0);
      headerPage.set_rootId(new PageId(-1));
    }


    // header = new LSHFPrefixTreeHeaderPage();
    // // Set an arbitrary magic number.
    // header.set_magic0(0x1234);
    // // Initially, there is no root.
    // rootId = new PageId(-1);
    // header.set_rootId(rootId);
    
    // // For simplicity, immediately create a new leaf page to serve as the root.
    // LSHFLeafPage leaf = new LSHFLeafPage(keyType);
    // rootId = leaf.getCurPage();
    // header.set_rootId(rootId);
    // if (DEBUG) {
    //   System.out.println("[LSHFPrefixTree] Created root page: " + rootId.pid);
    // }
    // In a full implementation, the header would be written to disk.
  }

  public LSHFPrefixTreeHeaderPage getHeaderPage() {
    return headerPage;
  }

  private void add_file_entry(String fileName, PageId pageno) throws AddFileEntryException {
    try {
      SystemDefs.JavabaseDB.add_file_entry(fileName, pageno);
    }
    catch (Exception e) {
      e.printStackTrace();
      throw new AddFileEntryException(e,"");
    }      
  }
  
  /**
   * Inserts a <key, RID> pair into the prefix tree.
   * For this simple implementation, we assume the tree contains only a single leaf page.
   * In a complete implementation, this method would traverse internal nodes and handle splits.
   * @param key the Vector100DKey (hash value) to insert.
   * @param rid the RID corresponding to the data record.
   * @throws Exception if insertion fails.
   */
  public void insert(Vector100DKey key, RID rid) throws Exception {

    LSHFKeyDataEntry newRootEntry;

    if (headerPage.get_rootId().pid == -1) {
        PageId newRootPageId;
        LSHFLeafPage newRootPage;
        RID dummyrid;
        
        newRootPage=new LSHFLeafPage( headerPage.get_keyType());
        newRootPageId=newRootPage.getCurPage();       
        
        // newRootPage.setNextPage(new PageId(INVALID_PAGE));
        // newRootPage.setPrevPage(new PageId(INVALID_PAGE));
        
        
        // ASSERTIONS:
        // - newRootPage, newRootPageId valid and pinned
        
        newRootPage.insertRecord(key, rid); 
        
        unpinPage(newRootPageId, true); /* = DIRTY */
        updateHeader(newRootPageId);
        
        return;
    }

    newRootEntry = _insert(key, rid, headerPage.get_rootId());

    if (newRootEntry != null) {
      LSHFIndexPage newRootPage;
      PageId newRootPageId;
      Object newEntryKey;

      newRootPage = new LSHFIndexPage(keyType);
      newRootPageId = newRootPage.getCurPage();

      newRootPage.insertKey(newRootEntry.key, ((IndexData)newRootEntry.data).getData());
    }

    // setPrevPage?

    return;
  }

  private LSHFKeyDataEntry _insert(Vector100DKey key, RID rid, PageId currentPageId) {
    return null;
  }

  private Page pinPage(PageId pageno) throws PinPageException {
    if (DEBUG) {
      System.out.println("[LSHFPrefixTree] pin page: " + pageno.pid);
    }
    try {
      Page page=new Page();
      SystemDefs.JavabaseBM.pinPage(pageno, page, false/*Rdisk*/);
      return page;
    }
    catch (Exception e) {
      throw new PinPageException(e,"");
    }
  }
  
  private void unpinPage(PageId pageno) throws UnpinPageException {
    if (DEBUG) {
      System.out.println("[LSHFPrefixTree] unpin page: " + pageno.pid);
    }
    try{
      SystemDefs.JavabaseBM.unpinPage(pageno, false /* = not DIRTY */);    
    }
    catch (Exception e) {
      throw new UnpinPageException(e,"");
    }
  }

  private void unpinPage(PageId pageno, boolean dirty) throws UnpinPageException {
    if (DEBUG) {
      System.out.println("[LSHFPrefixTree] unpin page: " + pageno.pid);
    }
    try{
      SystemDefs.JavabaseBM.unpinPage(pageno, dirty);    
    }
    catch (Exception e) {
      throw new UnpinPageException(e,"");
    }
  }

  private void updateHeader(PageId newRoot)
    throws   IOException, 
       PinPageException,
       UnpinPageException
  {
    LSHFPrefixTreeHeaderPage header;
    PageId old_data;

    header = new LSHFPrefixTreeHeaderPage(pinPage(headerPageId));
    old_data = headerPage.get_rootId();
    header.set_rootId(newRoot);
    unpinPage(headerPageId, true);
  }

  private PageId get_file_entry(String filename) throws GetFileEntryException {
    try {
      return SystemDefs.JavabaseDB.get_file_entry(filename);
    }
    catch (Exception e) {
      throw new GetFileEntryException(e,"");
    }
  }
  
  public void closePrefixTree() throws PageUnpinnedException, InvalidFrameNumberException, HashEntryNotFoundException, ReplacerException, IOException
  {
    if (headerPage!=null) {
      SystemDefs.JavabaseBM.unpinPage(headerPage.getPageId(), true);
      headerPage = null;
    }  
  }
}
