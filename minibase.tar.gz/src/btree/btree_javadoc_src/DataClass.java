package btree;

/** DataClass: An abstarct class. It will be extended 
 *  to be IndexData and LeafData.
 */ 
public abstract class DataClass{ 
}  
