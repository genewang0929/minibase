package iterator;

import global.Vector100Dtype;

public class Operand {
  public  FldSpec  symbol;
  public  String   string;
  public  int      integer;
  public  float    real;
  public Vector100Dtype vector100D;
}
